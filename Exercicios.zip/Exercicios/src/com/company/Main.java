package com.company;
import java.util.Scanner;
public class Main {


    public static void main(String[] args) {
        // write your code here

//        exercicio 1
//        String Planeta = "Plutão";
//        System.out.println("o Planeta é: " + Planeta);
//
//        secanners para entrada de dados
            Scanner scanner = new Scanner(System.in);
            Scanner entrada = new Scanner(System.in);

//        exercicio 2
//        System.out.print("informe seu nome: ");
//        String nomeUsuario = entrada.nextLine();
//
//        exercicio 3
//        System.out.print("informe seu nome: ");
//        String nomeUsuario = entrada.nextLine();
//        System.out.print("informe sua idade: ");
//        int idade = entrada.nextInt();
//        System.out.print("bom dia " + nomeUsuario + ", sua idade é " + idade);


//        exercicios 4
//        System.out.print("Digite a largura do retângulo: ");
//        double largura = entrada.nextDouble();
//        System.out.print("Digite a altura do retângulo: ");
//        double altura = entrada.nextDouble();
//        double area = largura * altura;
//        System.out.println("A área do retângulo é: " + area);
//        entrada.close();

//        System.out.print("Informe um lado: ");
//        double lado = entrada.nextDouble();
//        double area = lado * lado;
//        System.out.println("A soma do quadrado é: " + area);
//

//        System.out.print("Informe a diagonal maior: ");
//        double diagonanalMaior = entrada.nextDouble();
//        System.out.print("Informe a diagonal menor: ");
//        double diagonanalMenor = entrada.nextDouble();
//        double area = diagonanalMaior * diagonanalMenor / 2;
//        System.out.println("a area é: " + area);

//        System.out.println("Calculo da área do trapézio");
//        System.out.print("Informe a base maior: ");
//        double baseMaior = entrada.nextDouble();
//        System.out.print("Informe a base menor: ");
//        double baseMenor = entrada.nextDouble();
//        System.out.print("Informe a altura: ");
//        double altura = entrada.nextDouble();
//        double area = (baseMaior + baseMenor) * altura / 2;
//        System.out.println("a area é: " + area);


//        System.out.println("Calculo da área do paralelogramo");
//        System.out.print("informe a base: ");
//        double baseParalelogramo = scanner.nextDouble();
//        System.out.print("informe a altura: ");
//        double alturaParlelogramo = scanner.nextDouble();
//        double areaParalelogaramo = baseParalelogramo * alturaParlelogramo;
//        System.out.println("A área do paralelogramo é: " + areaParalelogaramo);
//

//        System.out.println("\nCálculo da área do triângulo");
//        System.out.print("informe a base: ");
//        double baseTriangulo = scanner.nextDouble();
//        System.out.print("informe a altura: ");
//        double alturaTriangulo= scanner.nextDouble();
//        double areaTriangulo = (baseTriangulo * alturaTriangulo) /2;
//        System.out.println("A área do triangulo é: " + areaTriangulo);
//

//        System.out.println("\nCalculo da área do círculo");
//        System.out.print("informe o raio: ");
//        double raio = scanner.nextDouble();
//        double areaCirculo = Math.PI * Math.pow(raio, 2);
//        System.out.println("á area do circulo é: " + areaCirculo);

//        exercicio 5
//        System.out.print("informe o valor: ");
//        double valor = entrada.nextDouble();
//        if(valor > 0)
//            System.out.println("o valor informado é positivo");
//        else if(valor < 0)
//            System.out.println("o valor informado é negativo");
//        else
//            System.out.println("o valor informado é neutro");

//        exercicio 6
//        System.out.print("Digite três valores diferentes: ");
//        double valor1 = scanner.nextDouble();
//        double valor2 = scanner.nextDouble();
//        double valor3 = scanner.nextDouble();
//        double maxValue = Math.max(valor1, Math.max(valor2, valor3));
//        System.out.println("o maior valor é: " + maxValue);

//        exercicio 6.1
//        System.out.println("Digite o primeiro valor");
//        double valor1 = entrada.nextDouble();
//        System.out.println("Digite o segundo valor");
//        double valor2 = entrada.nextDouble();
//        System.out.println("Digite o terceiro valor");
//        double valor3 = entrada.nextDouble();
//        System.out.println("Digite o quarto valor");
//        double valor4 = entrada.nextDouble();
//        if(valor1 > valor2 && valor1 > valor3 && valor1 > valor4){
//            System.out.println("O maior valor digitado é: " + valor1);
//        }else if(valor2 > valor3 && valor2 > valor4){
//            System.out.println("O maior valor digitado é: " + valor2);
//        }else if(valor3 > valor4){
//            System.out.println("O maior valor digitado é: " + valor3);
//        }else{
//            System.out.println("O maior valor digitado é: " + valor4);
//        }


//        exercicio 7
//        System.out.print("informe três valores distintos: ");
//        int valor1 = scanner.nextInt();
//        int valor2 = scanner.nextInt();
//        int valor3 = scanner.nextInt();
//
//        int soma;
//
//        if (valor1 < valor2 && valor1 < valor3) {
//            soma = valor2 + valor3;
//        } else if (valor2 < valor3) {
//            soma = valor1 + valor3;
//        } else {
//            soma = valor2 + valor1;
//        }
//
//        System.out.println("a soma dos valores é: " + soma);


//        exercicio 7.1
//        System.out.println("informe o primeiro valor ");
//        double valor1 = scanner.nextDouble();
//        System.out.println("informe o segundo valor ");
//        double valor2 = scanner.nextDouble();
//        System.out.println("informe o terceiro valor ");
//        double valor3 = scanner.nextDouble();
//        System.out.println("informe o quarto valor ");
//        double valor4 = scanner.nextDouble();
//        System.out.println("informe o quinto valor ");
//        double valor5 = scanner.nextDouble();
//
//        double primeiroValorMaior = Math.max(valor1,valor2);
//        double segundoValorMaior = Math.max(valor3,valor4);
//
//        if (primeiroValorMaior < valor5){
//            primeiroValorMaior = valor5;
//        }else if(segundoValorMaior < valor5){
//            segundoValorMaior = valor5;
//        }
//
//        double somaMaiorValor = primeiroValorMaior + segundoValorMaior;
//
//        System.out.println("o maior valor dos cinco é: "+somaMaiorValor);



    }
}